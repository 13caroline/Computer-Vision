var express = require('express');
var router = express.Router();
var Nobels = require('../controllers/nobels')

/* 
- GET /api/premios - Devolve a lista de prémios apenas com os campos "year" e "category";
- GET /api/premios/:id - Devolve a informação completa de um prémio;
- GET /api/categorias - Devolve a lista de categorias, sem repetições;
- GET /api/premios?categoria=YYY - Devolve a lista de prémios que tenham o campo "category" com o valor "YYY";
- GET /api/premios?categoria=YYY&data=AAAA - Devolve a lista de prémios que tenham o campo "category" com o valor "YYY" e o campo "year" com um valor superior a "AAAA";
- GET /api/laureados - Devolve uma lista ordenada alfabeticamente por nome dos laureados com os campos correspondentes ao nome, ano do prémio e categoria.
*/
router.get('/premios/:id', function(req, res, next) {
  Nobels.consultar(req.params.id)
    .then(dados => res.jsonp(dados))
    .catch(e => res.status(500).jsonp(e))
});

router.get('/premios', function(req, res, next) {
  if(req.query.categoria && req.query.data){
    Nobels.filtrarambos(req.query.categoria, req.query.data)
      .then(dados => res.jsonp(dados))
      .catch(e => res.status(500).jsonp(e))
  } 
  else if (req.query.categoria){
    Nobels.filtrarcategorias(req.query.categoria)
      .then(dados => res.jsonp(dados))
      .catch(e => res.status(500).jsonp(e))
  }
  else {
    Nobels.listar()
      .then(function (dados) {
        response = []
        dados.forEach(element => {
          item = {
            year : element.year,
            category : element.category
          }
          response.push(item)
        });
        res.jsonp(response)
      })
      .catch(e => res.status(500).jsonp(e))
  }
  
});

router.get('/categorias', function(req, res, next) {
  Nobels.categorias()
    .then(dados => res.jsonp(dados))
    .catch(e => res.status(500).jsonp(e))
});

router.get('/laureados', function(req, res, next) {
  Nobels.laureados()
    .then(dados => res.jsonp(dados))
    .catch(e => res.status(500).jsonp(e))
});

module.exports = router;
