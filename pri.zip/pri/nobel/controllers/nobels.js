var Nobel = require('../models/nobels')
var mongoose = require('mongoose')

module.exports.listar = () => {
    return Nobel
        .find()
        .exec()
}

module.exports.consultar = id => {
    return Nobel
        .findOne({_id: id})
        //.sort({'comentarios.data' : -1})
        .exec()
}

// Categorias
module.exports.categorias = () => {
    return Nobel
        .distinct("category")
        .exec()
}

// Filtrar Genero
module.exports.filtrarcategorias = (cat) => {
    return Nobel
        .find({category:cat})
        .exec()
}

// Filtrar Genero e Data
module.exports.filtrarambos = (cat, ano) => {
    return Nobel
        .find({category : cat, year : {$gte : ano}})
        .exec()
}
/* Atores
module.exports.atores = () => {
    return Nobel
        .distinct("cast")
        .exec()
}
*/
module.exports.laureados = () => {
    return Nobel
        .aggregate([{$unwind:"$laureates"},
            {$project:{name: {$concat:["$laureates.firstname"," ","$laureates.surname"]},prize:{year:"$year",category:"$category"}}}, 
            {$group:{_id:"$name",prizes:{$push:"$prize"}}},
            {$sort:{_id:1}}
        ])
        .exec();
}