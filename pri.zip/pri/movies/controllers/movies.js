var Movie = require('../models/movies')
var mongoose = require('mongoose')

module.exports.listar = () => {
    return Movie
        .find()
        .exec()
}

module.exports.consultar = id => {
    return Movie
        .findOne({_id: id})
        //.sort({'comentarios.data' : -1})
        .exec()
}

// Generos
module.exports.generos = () => {
    return Movie
        .distinct("genres")
        .exec()
}

// Filtrar Genero
module.exports.filtergender = (gender) => {
    return Movie
        .find({genres:gender})
        .exec()
}

// Filtrar Genero e Data
module.exports.filtergenderdate = (gender, ano) => {
    return Movie
        .find({genres : gender, year : {$gte : ano}})
        .exec()
}
// Atores
module.exports.atores = () => {
    return Movie
        .distinct("cast")
        .exec()
}

module.exports.cast = () => {
    return Movie
        .aggregate([{$unwind:"$cast"},
            {$project:{name: "$cast",movie:{year:"$year",title:"$title"}}}, 
            {$group:{_id:"$name",movies:{$push:"$movie"}}},
            {$sort:{_id:1}}
        ])
        .exec();
}