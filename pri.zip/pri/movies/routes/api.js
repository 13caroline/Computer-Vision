var express = require('express');
var router = express.Router();
var Movies = require('../controllers/movies')

/* 
- GET /api/filmes - Devolve a lista de filmes apenas com os campos "title" e "year";
- GET /api/filmes/:id - Devolve a informação completa de um filme identificado no pedido pelo seu identificador;
- GET /api/generos - Devolve a lista de generos em que os filmes se encontram classificados, sem repetições;
- GET /api/filmes?genro=Action - Devolve a lista de filmes cujo campo "genres" contem o valor "Action";
- GET /api/filmes?categoria=Action&data=AAAA - Devolve a lista de prémios cujo campo "genres" contenha o valor "Action" e o campo "year" com um valor superior a "AAAA";
- GET /api/atores - Devolve uma lista ordenada alfabeticamente por nome dos atores.
- GET /api/cast - Inversão estrutural.
*/

router.get('/filmes/:id', function(req, res, next) {
  Movies.consultar(req.params.id)
    .then(dados => res.jsonp(dados))
    .catch(e => res.status(500).jsonp(e))
});

router.get('/filmes', function(req, res, next) {
  if(req.query.genero && req.query.ano){
    Movies.filtergenderdate(req.query.genero, Number(req.query.ano))
      .then(dados => res.jsonp(dados))
      .catch(e => res.status(500).jsonp(e))
  }
  else if(req.query.genero){
    Movies.filtergender(req.query.genero)
      .then(dados => res.jsonp(dados))
      .catch(e => res.status(500).jsonp(e))
  }
  else {
    Movies.listar()
      .then(dados => res.jsonp(dados))
      .catch(e => res.status(500).jsonp(e))
  }
});

router.get('/generos', function(req, res, next) {
  Movies.generos()
    .then(function (dados) {
      response = dados
      response.sort()
      res.jsonp(response)
    })
    .catch(e => res.status(500).jsonp(e))
});

router.get('/atores', function(req, res, next) {
  Movies.atores()
    .then(function (dados) {
      response = dados
      response.sort()
      res.jsonp(response)
    })
    .catch(e => res.status(500).jsonp(e))
});

router.get('/cast', function(req, res, next) {
  Movies.cast()
    .then(function (dados) {
      res.jsonp(dados)
    })
    .catch(e => res.status(500).jsonp(e))
});

module.exports = router;
