var express = require('express');
var router = express.Router();
var axios = require('axios')
/*
start_date, distance, moving_time, type
GET /api/atividades - lista as atividades no dataset com os seguintes campos: data, tipo de atividade, distância em Km e tempo;
GET /api/atividades/:tipo - lista as atividades que pertencem ao tipo indicado;
GET /api/atividades?filtro=maislonga - devolve a atividade com a duração mais longa;
GET /api/atividades/:tipo?filtro=maislonga - devolve a atividade mais longa do tipo indicado.
*/

router.get('/atividades/:tipo', function(req, res, next) {
  if(req.query.filtro.startsWith('maislonga')){
    axios.get('http://localhost:5025/atividades?type=' + req.params.tipo + '&_sort=moving_time&_order=desc&_limit=1')
      .then(function (dados) {
        element = dados.data[0]
        response = {
          data : element.start_date,
          distancia : element.distance,
          tempo : element.moving_time,
          tipo : element.type
        }
        res.jsonp(response);
      })
      .catch(e => res.jsonp(e))
  }
  else {
    axios.get('http://localhost:5025/atividades?type=' + req.params.tipo)
      .then(function (dados) {
        response = []
        dados.data.forEach(element => { 
          item = {
            data : element.start_date,
            distancia : element.distance,
            tempo : element.moving_time,
            tipo : element.type
          }
          response.push(item)
        });
        res.jsonp(response);
      })
      .catch(e => res.jsonp(e))
  }
});

router.get('/atividades', function(req, res, next) {
  if(req.query.filtro.startsWith('maislonga')){
    axios.get('http://localhost:5025/atividades?_sort=moving_time&_order=desc&_limit=1')
      .then(function (dados) {
        element = dados.data[0]
        response = {
          data : element.start_date,
          distancia : element.distance,
          tempo : element.moving_time,
          tipo : element.type
        }
        res.jsonp(response);
      })
      .catch(e => res.jsonp(e))
  }
  else {
    axios.get('http://localhost:5025/atividades')
      .then(function (dados) {
        response = []
        dados.data.forEach(element => { 
          item = {
            data : element.start_date,
            distancia : element.distance,
            tempo : element.moving_time,
            tipo : element.type
          }
          response.push(item)
        });
        res.jsonp(response);
      })
      .catch(e => res.jsonp(e))
  }
});

module.exports = router;
