var express = require('express');
var router = express.Router();
var Publicacoes = require('../controllers/publicacoes')
var Publicacao = require('../models/publicacao')

router.get('/', function (req,res) {
  Publicacoes.listar()
  .then(dados => {
    res.render('index', {lista : dados});
  })
  .catch(erro => {
    res.render('error', {error : erro})
  })
})

router.post('/', function (req,res) {
  Publicacoes.inserir(req.body)
  .then(dados => {
    res.redirect('/')
  })
  .catch(erro => {
    res.render('error', {error : erro})
  })
})

router.post('/:id' , function (req,res) {
  Publicacoes.adicionar_gosto(req.params.id, {
    autor : 'teste'
  })
    .then(dados => {
      res.redirect('/')
    })
    .catch(erro => {
      res.render('error', {error : erro})
    })
});

module.exports = router;
