const mongoose = require('mongoose')

var GostoSchema = new mongoose.Schema({
    autor : String
})

var publicacaoSchema = new mongoose.Schema({
    texto : String,
    autor : String, 
    hash : String,
    gostos : [GostoSchema]    
})

module.exports = mongoose.model('publicacoes', publicacaoSchema)