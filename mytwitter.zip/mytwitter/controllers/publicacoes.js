var Publicacao = require('../models/publicacao')

module.exports.listar = () => {
    return Publicacao
        .find()
        .exec()
}

module.exports.inserir = p =>{
    p.gostos = []
    var novo = new Publicacao(p)
    return novo.save()
}

module.exports.adicionar_gosto = (id, gosto) => {
    return Publicacao
        .findOneAndUpdate({ _id: id }, { $push: {gostos : gosto}})
        .exec()
}